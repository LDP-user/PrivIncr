import numpy as np


def random_response(bit_array: np.ndarray, p, q=None):
    """
    :param bit_array:
    :param p: probability of 1->1
    :param q: probability of 0->1
    update: 2020.03.06
    :return:
    """
    q = 1-p if q is None else q
    if isinstance(bit_array, int):
        probability = p if bit_array == 1 else q
        return np.random.binomial(n=1, p=probability)
    return np.where(bit_array == 1, np.random.binomial(1, p, len(bit_array)), np.random.binomial(1, q, len(bit_array)))


def optimized_unary_encoding(bit_array: np.ndarray, epsilon):
    """
    the OUE, the p and q is revised.
    update: 2021.04.20
    """
    p = 1 / 2
    q = 1 / (np.e ** epsilon + 1)
    return random_response(bit_array, p, q)


def perturb(encode_data, epsilon):
    perturb_data = []
    if isinstance(encode_data[0][0], int):
        for item in encode_data:
            perturb_item = optimized_unary_encoding(np.array(item), epsilon)
            perturb_data.append(perturb_item.tolist())
        return perturb_data
    else:
        num_attributes = len(encode_data[0])
        for encode_data_ in encode_data:
            perturb_data_ = []
            for item in encode_data_:
                perturb_item = optimized_unary_encoding(np.array(item), epsilon / num_attributes)
                perturb_data_.append(perturb_item.tolist())
            perturb_data.append(perturb_data_)
        return perturb_data