from functools import reduce
import general


def encode_to_binary_string(value, categories):
    # bits = ['0' if i != value - 1 else '1' for i in range(categories)]
    # return "".join(bits)
    return [0 if i != value else 1 for i in range(categories)]


def encode(user_data, num_categories):
    merge_categories = reduce(lambda x, y: x * y, num_categories)
    merge_data = []
    merge_encode = []
    for item in user_data:
        merge = general.categorical_list_to_num(item, num_categories)
        merge_data.append(merge)
        merge_encode.append(encode_to_binary_string(merge, merge_categories))
    return merge_encode


def encode_all(user_data, num_categories):
    encode_data = []
    for item in user_data:
        encode_data_ = []
        for index, value in enumerate(item):
            encode_data_.append(encode_to_binary_string(value, num_categories[index]))
        encode_data.append(encode_data_)
    return encode_data