import numpy as np
from functools import reduce

import estimate
import general

def cliques_distribution_estimation(dataset, tree, DG, epsilon, clique_size):

    nodes = tree.tree.nodes

    cliques_distributions = [[] for i in range(len(nodes))]
    all_cliques = []
    factorized_cliques = []

    # factorize
    for index, item in enumerate(nodes):

        dom = get_domain(item, dataset.num_categories)

        if dom > clique_size:

            attribute = [i for i in item]
            attribute.sort()

            cliques = get_cliques(DG.MI, attribute[:], dataset.num_categories)
            factorized_cliques.append(cliques)

            larger_clique = []
            for clique in cliques:
                if len(clique[1]) >= 2:
                    sorted_list = [clique[0]] + clique[1]
                    sorted_list.sort()
                    larger_clique.append(sorted_list)
            if larger_clique:
                all_cliques.append(larger_clique)
            pass

        elif len(item) == 1:
            sum_distribution = get_clique1_dist(item, dataset.num_attributes, dataset.num_categories, DG.graph)
            cliques_distributions[index] = estimate.post_processing(sum_distribution[:]).tolist()
            factorized_cliques.append([[item[0]]])

        elif len(item) == 2:
            distribution = get_clique2_dist(item, dataset.num_attributes, DG.graph)
            cliques_distributions[index] = distribution
            sorted_list = list(item)
            sorted_list.sort()
            factorized_cliques.append([sorted_list])

        else:
            sorted_list = list(item)
            sorted_list.sort()
            all_cliques.append([sorted_list])
            factorized_cliques.append([sorted_list])

    # combine
    final_cliques = combine_small_cliques(all_cliques)

    # estimate
    final_cliques_distribution = []
    clique_domain = 0
    for item in final_cliques:
        clique_domain += reduce(lambda a, b: a * b, [dataset.num_categories[i] for i in item])

    for item in final_cliques:
        usersize = int((reduce(lambda a, b: a * b, [dataset.num_categories[i] for i in item]) / clique_domain) * (dataset.num_records - dataset.num_used))
        users = dataset.upload_trans(item, usersize, epsilon)

        c_list = estimate.unbiased(users, epsilon)
        distribution = estimate.post_processing(c_list)
        final_cliques_distribution.append(distribution[:])

    for index, item in enumerate(nodes):
        if not cliques_distributions[index]:
            sorted_item_list = list(item)
            sorted_item_list.sort()
            if get_domain(item, dataset.num_categories) > clique_size:
                clique_dist = []
                for clique in factorized_cliques[index]:
                    if len(clique[1]) == 0:
                        clique_dist.append(
                            get_clique1_dist([clique[0]], dataset.num_attributes, dataset.num_categories, DG.graph))
                    elif len(clique[1]) == 1:
                        distribution = get_clique2_dist([clique[0], clique[1][0]], dataset.num_attributes, DG.graph)
                        sorted_list = [clique[0]] + clique[1]
                        sorted_list.sort()
                        distribution_ = sum_part_from_all(clique[1], [sorted_list], dataset.num_categories, [distribution])
                        conditional_distribution = get_conditional_distribution(clique[1], sorted_list, dataset.num_categories, distribution_, distribution)
                        clique_dist.append(conditional_distribution)
                    else:
                        sorted_list = [clique[0]] + clique[1]
                        sorted_list.sort()
                        # 3
                        if tuple(sorted_list) in DG.cover_distribution.keys():
                            distribution = DG.cover_distribution[tuple(sorted_list)]
                        else:
                            # P(ABCD)
                            distribution = sum_part_from_all(sorted_list, final_cliques, dataset.num_categories, final_cliques_distribution)
                        # P(BCD)
                        distribution_ = sum_part_from_all(clique[1], [sorted_list], dataset.num_categories, [distribution])
                        # P(A|BCD)
                        conditional_distribution = get_conditional_distribution(clique[1], sorted_list, dataset.num_categories, distribution_, distribution)
                        clique_dist.append(conditional_distribution)
                cliques_distributions[index] = mul_conditional_distribution(sorted_item_list, dataset.num_categories, factorized_cliques[index], clique_dist)
            else:
                cliques_distributions[index] = sum_part_from_all(sorted_item_list, final_cliques, dataset.num_categories, final_cliques_distribution)

    return cliques_distributions


def get_mrmr(I_matrix, sk, target_attribute):
    d = 0
    r = 0
    for item in sk:
        if item < target_attribute:
            d += I_matrix[item][target_attribute]
        elif item > target_attribute:
            d += I_matrix[target_attribute][item]
    num = 0
    for i in range(len(sk)):
        for j in range(len(sk)):
            if sk[i] < sk[j]:
                r += I_matrix[sk[i]][sk[j]]
                num += 1
    r /= len(sk)

    return d - r


def get_domain(candidate_set, categories):
    mul = 1
    for item in candidate_set:
        mul *= categories[item]
    return mul


def feature_select(I_matrix, attribute_set, target_attribute):
    sk = []
    mrmr1 = -1
    del_index = -1

    for index, value in enumerate(attribute_set):
        if value < target_attribute and I_matrix[value][target_attribute] > mrmr1:
            mrmr1 = I_matrix[value][target_attribute]
            del_index = index
        elif value > target_attribute and I_matrix[target_attribute][value] > mrmr1:
            mrmr1 = I_matrix[target_attribute][value]
            del_index = index
    sk.append(attribute_set[del_index])
    attribute_set.pop(del_index)
    del_index = -1
    mrmr2 = -1
    while 1:
        if not attribute_set:
            return sk

        for index, value in enumerate(attribute_set):
            mrmr = get_mrmr(I_matrix, sk + [value], target_attribute)
            if mrmr > mrmr2:
                mrmr2 = mrmr
                del_index = index
        if mrmr1 >= mrmr2:
            return sk
        else:
            sk.append(attribute_set[del_index])
            attribute_set.pop(del_index)
            mrmr1 = mrmr2
            mrmr2 = -1


def get_cliques(I_matrix, attributes, categories):
    cliques = []
    d = len(attributes)
    for i in range(d):
        if get_domain(attributes, categories) >= 2**12:
            min_clique = []
            min_var = 1000000
            min_index = -1
            for index_attr, value in enumerate(attributes):
                attribute_set = attributes[:]
                attribute_set.pop(index_attr)
                clique = feature_select(I_matrix, attribute_set, value)
                dom_var = get_domain(clique + [value], categories)
                if dom_var < min_var:
                    min_var = dom_var
                    min_index = index_attr
                    min_clique = clique
            min_clique.sort()
            cliques.append([attributes[min_index], min_clique[:]])
            attributes.pop(min_index)
        else:
            max_var = -1
            max_index = -1
            for index_attr, value in enumerate(attributes):
                if categories[value] > max_var:
                    max_var = categories[value]
                    max_index = max_index
            temp = attributes.pop(max_index)
            attributes.sort()
            cliques.append([temp, attributes[:]])
    return cliques


def combine_small_cliques(cliques_set):
    final_cliques = []
    for cliques in cliques_set:
        for clique in cliques:
            flag = True
            repeat_flag = True
            for index, value in enumerate(final_cliques):
                if set(clique) & set(value) == set(clique):
                    flag = False
                    break
                elif set(clique) & set(value) == set(value):
                    if repeat_flag:
                        final_cliques[index] = clique
                        repeat_flag = False
                    else:
                        final_cliques.pop(index)
                    flag = False
            if flag:
                final_cliques.append(clique)
    return final_cliques


def mul_list_element(target_list):
    return reduce(lambda x, y: x * y, target_list)


def get_relative_position(target_attributes, attributes):
    relative_index = []
    addition_list = []
    i = 0
    j = 0
    while j < len(attributes):
        if i < len(target_attributes) and target_attributes[i] == attributes[j]:
            relative_index.append(j)
            i += 1
            j += 1
        else:
            addition_list.append(attributes[j])
            j += 1
    return relative_index, addition_list


def all_index_to_part(index, target_attributes, attributes, relative_index, num_categories):
    categorical_list = general.num_to_categorical_list(index, np.array(num_categories)[attributes].tolist())
    target_index = general.categorical_list_to_num(np.array(categorical_list)[relative_index].tolist(),
                                                   np.array(num_categories)[target_attributes].tolist())
    return target_index


def get_part_from_all(target_attributes, attributes, num_categories, distribution):
    relative_index, addition_list = get_relative_position(target_attributes, attributes)
    merge_category = mul_list_element(np.array(num_categories)[target_attributes])
    c = mul_list_element(np.array(num_categories)[addition_list])
    target_distribution = np.zeros(merge_category)
    for index, p in enumerate(distribution):
        target_index = all_index_to_part(index, target_attributes, attributes, relative_index, num_categories)
        target_distribution[target_index] += p
    return merge_category, c, target_distribution


def get_clique1_dist(clique, num_attributes, num_categories, graph0):
    num = num_categories[clique[0]]
    distributions = []
    c_list = []
    sum_distribution = np.zeros(num)
    for i in range(num_attributes):
        if i != clique[0]:
            min_i = min(i, clique[0])
            max_i = max(i, clique[0])
            distribution_ = graph0[min_i * num_attributes + max_i].summarize_frequency[-1][:]
            n = graph0[min_i * num_attributes + max_i].summarize_num_users[-1]
            weight = num_categories[i]
            c_list.append(1 / (weight * n))
            distribution = np.zeros(num)
            if clique[0] == min_i:
                for index_p, p in enumerate(distribution_):
                    index_item = int(index_p / weight)
                    distribution[index_item] += p
            else:
                for index_p, p in enumerate(distribution_):
                    index_item = index_p % num
                    distribution[index_item] += p
            distributions.append(distribution)
    sum_c = sum(c_list)
    for index_c in range(len(c_list)):
        sum_distribution += c_list[index_c] / sum_c * distributions[index_c]
    return sum_distribution


def get_clique2_dist(clique, num_attributes, graph0):
    index_i = min(clique[0], clique[1])
    index_j = max(clique[0], clique[1])
    edge = graph0[index_i * num_attributes + index_j]
    distribution = estimate.post_processing(edge.summarize_frequency[-1][:])
    return distribution.tolist()


def sum_part_from_all(target_clique, all_cliques, num_categories, all_cliques_distribution):
    part_distributions = []
    c_list = []
    for index, clique in enumerate(all_cliques):
        if target_clique == clique:
            return all_cliques_distribution[index]
        elif set(target_clique) & set(clique) == set(target_clique):
            num, c, part_distribution = get_part_from_all(target_clique, clique, num_categories, all_cliques_distribution[index])
            part_distributions.append(part_distribution)
            c_list.append(1/c)
    sum_distribution = np.zeros(num)
    sum_c = sum(c_list)
    for index_c in range(len(c_list)):
        sum_distribution += c_list[index_c] / sum_c * part_distributions[index_c]
    return sum_distribution.tolist()


def get_conditional_distribution(attributes_, attributes, num_categories, distribution_, distribution):
    conditional_distribution = []
    relative_index, _ = get_relative_position(attributes_, attributes)
    for index, p in enumerate(distribution):
        target_index = all_index_to_part(index, attributes_, attributes, relative_index, num_categories)
        conditional_distribution.append(p / distribution_[target_index])
    return conditional_distribution


def mul_conditional_distribution(attributes, num_categories, cliques, conditional_distributions):
    merge_num = mul_list_element(np.array(num_categories)[attributes])
    merge_distribution = []
    for i in range(merge_num):
        mul_temp = 1
        for index, clique in enumerate(cliques):
            attributes_ = [clique[0]] + clique[1]
            attributes_.sort()
            relative_index, _ = get_relative_position(attributes_, attributes)
            target_index = all_index_to_part(i, attributes_, attributes, relative_index, num_categories)
            mul_temp *= conditional_distributions[index][target_index]
        merge_distribution.append(mul_temp)
    return merge_distribution