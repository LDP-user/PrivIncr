import copy
import random

import synthesizer
from dataset import Dataset
from dependency_graph import DependencyGraph
import clique_factorize

from mbi.domain import Domain
from mbi.junction_tree import JunctionTree


def PrivIncr(filename, epsilon, num_iterations, phi, coefficient, clique_size):

    # read data
    dataset = Dataset(filename)
    random.shuffle(dataset.users)

    # parameters
    unit = coefficient / num_iterations
    datasize_init = int(unit * dataset.num_records)
    datasize_opti = [datasize_init for _ in range(num_iterations - 1)]

    # construct dependency graph
    DG = DependencyGraph(dataset, epsilon, num_iterations - 1, phi, datasize_init, datasize_opti)
    DG.construct_graph(dataset)

    edges = []
    for item in DG.graph:
        if item.attributes != (-1, -1):
            edges.append(item.attributes)

    # transform to junction tree
    domain = Domain([i for i in range(dataset.num_attributes)], dataset.num_categories)
    tree = JunctionTree(domain, edges)
    nodes = tree.tree.nodes

    # dispose neighbors
    neighbors = tree.neighbors()
    for key in neighbors.keys():
        key_neighbor = copy.deepcopy(neighbors[key])
        for item in neighbors[key]:
            if set(key).intersection(set(item)) == set():
                key_neighbor.remove(item)
        neighbors[key] = key_neighbor

    # estimate cliques distribution
    cliques_distributions = clique_factorize.cliques_distribution_estimation(dataset, tree, DG, epsilon, clique_size)

    cliques = {}
    alones = {}
    for index, node in enumerate(nodes):
        distribution = cliques_distributions[index]
        if neighbors[node] == set():
            alones[node] = distribution
        else:
            cliques[node] = distribution

    print("The structure of Junction Tree:")
    for key in neighbors.keys():
        print("Clique", key, "has neighbors", neighbors[key], "with distribution", alones[key] if neighbors[key]==set() else cliques[key])

    # synthesize new dataset
    syn_data = []
    for i in range(dataset.num_records):
        syn_data.append(synthesizer.synthesis_data(cliques, alones, neighbors, dataset.num_attributes, dataset.num_categories))
    # save synthesize data
    synthesizer.save_synthesis_data(dataset, syn_data, filename)


if __name__ == '__main__':
    PrivIncr(filename="adult", epsilon=6, num_iterations=7, phi=0.3, coefficient=0.5, clique_size=pow(2, 12))