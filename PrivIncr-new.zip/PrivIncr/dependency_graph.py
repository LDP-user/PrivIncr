import estimate
import numpy as np
import math

import general


class Edge:

    def __init__(self, attributes=(-1, -1), num_categories=(0, 0)):
        self.attributes = attributes
        self.num_categories = num_categories

        self.frequency = []
        self.summarize_frequency = []

        self.summarize_num_users = []
        self.summarize_c_list = []
        self.summarize_c_product_n = []

    def frequency_summarize(self):
        w1 = self.summarize_c_product_n[-2] / self.summarize_c_product_n[-1]
        w2 = 1 - w1
        sumarize_t = w1 * np.array(self.summarize_frequency[-1]) + w2 * np.array(self.frequency[-1])

        self.summarize_frequency.append(sumarize_t)


class DependencyGraph:

    def __init__(self, dataset, epsilon, num_iteration, phi, datasize_init, datasize_opti):
        self.graph = []  # [edge0, ... ]  (d*d,1) i*d+j
        self.MI = np.zeros([dataset.num_attributes, dataset.num_attributes])
        self.num_attributes = dataset.num_attributes
        self.num_categories = dataset.num_categories
        self.epsilon = epsilon
        self.num_iteration = num_iteration
        self.phi = phi
        self.datasize_init = datasize_init
        self.datasize_opti = datasize_opti
        self.num_edges = general.Cni(dataset.num_attributes, 2)
        self.cover_distribution = {}


    def compute_mutual_information(self, ai, aj, category_ai, category_aj, distribution):
        self.MI[ai][aj] = 0
        p1s = np.zeros([category_ai, 1])
        p2s = np.zeros([category_aj, 1])
        for index, p in enumerate(distribution):
            index1 = int(index / category_aj)
            index2 = index % category_aj
            p1s[index1] += p
            p2s[index2] += p
        for index, p in enumerate(distribution):
            index1 = int(index / category_aj)
            index2 = index % category_aj
            self.MI[ai][aj] += p * math.log(p / (p1s[index1] * p2s[index2]), 2)


    def determine_correlation(self, ai, aj, category_ai, category_aj):
        if self.MI[ai][aj] >= min(category_ai - 1, category_aj - 1) * pow(self.phi, 2) / 2:
            return True
        else:
            return False

    def print_edges(self, times):
        edges = []
        for item in self.graph:
            if item.attributes != (-1, -1):
                edges.append(item.attributes)
        print("The dependency graph's edges in ", times, "-th iteration:")
        print(edges)


    def construct_graph(self, dataset):
        # init graph
        edge_domain = 0
        for i in range(self.num_attributes):
            for j in range(i + 1, self.num_attributes):
                edge_domain += dataset.num_categories[i] * dataset.num_categories[j]
        for i in range(self.num_attributes):
            for j in range(self.num_attributes):
                if i < j:
                    # assign users with encode and perturb
                    usersize = int((dataset.num_categories[i] * dataset.num_categories[j] / edge_domain) * self.datasize_init)
                    users = dataset.upload_trans((i, j), usersize, self.epsilon)
                    # estimate distribution
                    frequency = estimate.unbiased(users, self.epsilon)
                    distribution = estimate.post_processing(frequency)
                    # calculate mutual information
                    self.compute_mutual_information(i, j, self.num_categories[i], self.num_categories[j], distribution)
                    # init edge
                    edge_ = Edge((i, j), (dataset.num_categories[i], dataset.num_categories[j]))
                    edge_.frequency.append(frequency[:])
                    edge_.summarize_frequency.append(frequency[:])
                    edge_.summarize_c_list.append(1)
                    edge_.summarize_num_users.append(usersize)
                    edge_.summarize_c_product_n.append(1 / (1 * usersize))
                    # select edge
                    if self.determine_correlation(i, j, dataset.num_categories[i], dataset.num_categories[j]):
                        self.graph.append(edge_)
                    else:
                        edge_.attributes = (-1, -1)
                        self.num_edges -= 1
                        self.graph.append(edge_)
                else:
                    self.graph.append(Edge())

        self.print_edges(0)

        # opti graph
        for t in range(self.num_iteration):
            edge_domain = 0
            for index, item in enumerate(self.graph):
                if item.attributes != (-1, -1):
                    edge_domain += item.num_categories[0] * item.num_categories[1]
            for index, item in enumerate(self.graph):
                if item.attributes != (-1, -1):
                    # assign users with encode and perturb
                    usersize_t = int(item.num_categories[0] * item.num_categories[1] / edge_domain * self.datasize_opti[t])
                    users = dataset.upload_trans(item.attributes, usersize_t, self.epsilon)
                    # estimate distribution
                    frequency = estimate.unbiased(users, self.epsilon)
                    # data aggregation
                    edge_ = self.graph[index]
                    edge_.frequency.append(frequency)
                    edge_.summarize_num_users.append(edge_.summarize_num_users[-1] + usersize_t)
                    edge_.summarize_c_list.append(edge_.summarize_c_list[-1] + 1)
                    edge_.summarize_c_product_n.append(edge_.summarize_c_product_n[-1] + 1 / (1 * usersize_t))
                    edge_.frequency_summarize()
                    # re-calculate mutual information and re-determine correlation
                    i = item.attributes[0]
                    j = item.attributes[1]
                    distribution = estimate.post_processing(edge_.summarize_frequency[-1])
                    self.compute_mutual_information(i, j, self.num_categories[i], self.num_categories[j], distribution)
                    if not self.determine_correlation(i, j, dataset.num_categories[i], dataset.num_categories[j]):
                        edge_.attributes = (-1, -1)
                        self.num_edges -= 1
            self.print_edges(t + 1)