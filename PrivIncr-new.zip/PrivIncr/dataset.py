import pickle
import numpy as np
import encode
import perturb


class Error(Exception):
    pass


class Dataset:

    def __init__(self, filename):
        self.num_used = 0
        self.reload_data(filename)

    def reload_data(self, filename):
        load_file = open("E:/PrivIncr/" + filename + ".pkl", 'rb')

        load_data = pickle.load(load_file)

        self.num_records = load_data["num_records"]
        self.num_attributes = load_data["num_attributes"]
        self.num_categories = load_data["num_categories"]
        self.users = load_data["users"]

        load_file.close()


    def load_users(self, num_user):
        if self.num_used + num_user > self.num_records:
            raise Error("The remaining records are not enough!")
        else:
            self.num_used += num_user
            return self.users[self.num_used - num_user + 1:self.num_used]


    def upload_trans(self, attributes, num_user, epsilon):
        # random select and remove num_user from self.users
        users = self.load_users(num_user)
        # trans
        users = np.array(users)[:, attributes]
        num_categories = np.array(self.num_categories)[attributes, ].tolist()
        # encode
        encode_users = encode.encode(users, num_categories)
        # perturb
        perturb_users = perturb.perturb(encode_users, epsilon)
        # return
        return perturb_users
