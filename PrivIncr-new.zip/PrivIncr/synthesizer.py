import pickle
import numpy as np
import random
import general

def synthesis_data(cliques, alones, neighbors, num_attributes, num_categories):

    syn_record = np.zeros(num_attributes, dtype=np.int32)
    issyn = np.zeros(num_attributes, dtype=np.int32)

    for key in alones.keys():
        r = random.random()
        sum_pro = 0
        flag = 0
        for index, item in enumerate(alones[key]):
            sum_pro += item
            if sum_pro >= r:
                flag = index
                break
        sampled_result = general.num_to_categorical_list(flag, [num_categories[int(i)] for i in key])
        for index, item in enumerate(key):
            syn_record[int(item)] = int(sampled_result[index])
            issyn[int(item)] = 1

    not_visited = list(cliques.keys())
    rand = random.randint(0, len(not_visited)-1)
    queue = [not_visited[rand]]
    while(len(not_visited) > 0):
        #
        if len(queue) == 0:
            rand = random.randint(0, len(not_visited) - 1)
            queue.append(not_visited[rand])
        clique = queue.pop(0)
        not_visited.remove(clique)
        #
        for item in neighbors[clique]:
            if item in not_visited:
                queue.append(item)
        #
        issampled = [1 if issyn[int(i)] else 0 for i in clique]
        if not all(issampled):
            if not any(issampled):
                # [0,0,0,0]
                r = random.random()
                sum_pro = 0
                flag = 0
                for index, item in enumerate(cliques[clique]):
                    sum_pro += item
                    if sum_pro >= r:
                        flag = index
                        break
                sampled_result = general.num_to_categorical_list(flag, [num_categories[int(i)] for i in clique])
                for index, item in enumerate(clique):
                    syn_record[int(item)] = int(sampled_result[index])
                    issyn[int(item)] = 1
            else:
                conditional = general.candidate_code(clique, issyn, syn_record, num_categories)
                try:
                    conditional_pro = [cliques[clique][general.categorical_list_to_num(cond, [num_categories[int(i)] for i in clique])] for cond in conditional]
                except Exception as e:
                    print("error:", e)
                normalize_pro = np.array(conditional_pro) / sum(conditional_pro)
                r = random.random()
                sum_pro = 0
                flag = 0
                for index, item in enumerate(normalize_pro):
                    sum_pro += item
                    if sum_pro >= r:
                        flag = index
                        break
                sampled_result = conditional[flag]
                for index, item in enumerate(clique):
                    syn_record[int(item)] = int(sampled_result[index])
                    issyn[int(item)] = 1

    assert all(issyn), 'some attributes has not been sampled'

    return syn_record


# 用于生成pkl数据格式文件
def save_pickle_data(data, file_path):
    output = open(file_path, 'wb')
    pickle.dump(data, output, protocol=2)
    output.close()

def save_synthesis_data(dataset, synthesis_data, filename):
    data = {
        'num_records': dataset.num_records,
        'num_attributes': dataset.num_attributes,
        'num_categories': dataset.num_categories,
        'users': synthesis_data
    }
    save_pickle_data(data, "E:/PrivIncr/synthesis/syn_"+filename+".pkl")