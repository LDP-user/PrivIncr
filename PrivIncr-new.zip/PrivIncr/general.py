import copy
import numpy as np
from itertools import product
from _functools import reduce


def norm_sub(est_dist, num_records):
    estimates = np.copy(est_dist)
    n = num_records
    while (np.fabs(sum(estimates) - n) > 1) or (estimates < 0).any():
        estimates[estimates < 0] = 0
        total = sum(estimates)
        mask = estimates > 0
        diff = (n - total) / sum(mask)
        estimates[mask] += diff
    return estimates


def Cni(n, i):
    return reduce(lambda x, y: x * y, range(n - i + 1, n + 1)) / reduce(lambda x, y: x * y, range(1, i + 1))


def candidate_code(index_list, issyn, sampledreults, num_categories):
    loop_val = []
    for index in index_list:
        if issyn[int(index)]:
            loop_val.append([sampledreults[int(index)]])
        else:
            loop_val.append([j for j in range(num_categories[int(index)])])
    return list(product(*loop_val))


def num_to_categorical_list(num, categories_list):
    weights = []
    weight = 1
    ret_list = []

    categories_list_temp = copy.deepcopy(categories_list)
    categories_list_temp.reverse()
    for value in categories_list_temp:
        weight *= value
        weights.append(weight)

    weights.reverse()

    for w in weights[1:]:
        ret_list.append(num // w)
        num %= w

    ret_list.append(num)

    return ret_list


def categorical_list_to_num(index_list, categories_list):
    weights = []
    weight = 1
    num = 0

    categories_list_temp = copy.deepcopy(categories_list)
    categories_list_temp.reverse()
    for value in categories_list_temp:
        weight *= value
        weights.append(weight)

    weights.reverse()

    for index, value in enumerate(index_list):
        if index < len(index_list) - 1:
            num += value * weights[index + 1]
        else:
            num += value

    return num


def view_key_to_index(view_key, view_num_categories):
    index_list = []
    categories_list = []

    for index, value in enumerate(view_num_categories):
        if not value == 0:
            index_list.append(view_key[index])
            categories_list.append(value)

    return categorical_list_to_num(index_list, categories_list)


def list_and_list(list1, list2):
    assert len(list1) == len(list2)

    ret_list = []
    for i in range(len(list1)):
        ret_list.append(list1[i] * list2[i])
    return ret_list


def getjoint_distribution_from_all(ai, aj, joint_distribution_all, categories_list):
    w1 = categories_list[aj]
    w2 = 1

    joint_distribution_ij = np.zeros([categories_list[ai] * categories_list[aj], 1])
    temp = categories_list[:]
    temp.reverse()
    weights = [1]
    for i in range(len(temp)-1):
        weights.append(temp[i] * weights[i])
    weights.reverse()
    wi = weights[ai]
    wj = weights[aj]
    for index, p in enumerate(joint_distribution_all):
        index1 = int(index / wi) % categories_list[ai]
        index2 = int(index / wj) % categories_list[aj]
        index_ = w1 * index1 + w2 * index2
        joint_distribution_ij[index_] += p
    return joint_distribution_ij
