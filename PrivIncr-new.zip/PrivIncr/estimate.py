import numpy as np


def post_processing(c_list):
    dis = np.where(c_list <= 1, 1, np.rint(c_list))
    return dis / sum(dis)


def decode(bit_array_list: np.ndarray, p: float, q=None):
    q = 1 - p if q is None else q
    n = bit_array_list.shape[0]
    y = np.sum(bit_array_list, axis=0)
    result_list = (y - n * q) / (p - q)
    return result_list


def unbiased(perturb_data, epsilon):
    p = 1 / 2
    q = 1 / (np.e ** epsilon + 1)
    return decode(np.array(perturb_data), p, q)
